using NUnit.Framework;
using OpenQA.Selenium;
using System;


namespace Sklad
{
    public class Autotest_Main
    {
        IWebDriver Browser;
        [SetUp]
        // Test-case �1.1
        public void test_Go_To_Site()
        {
            //declaring variable Browser
            Browser = new OpenQA.Selenium.Chrome.ChromeDriver("C:\\Users\\User\\.nuget\\packages\\selenium.chrome.webdriver\\76.0.0\\driver");
            //Maximizing browser window
            Browser.Manage().Window.Maximize();
            //opening target site
            Browser.Navigate().GoToUrl("http://site1//index.php");
            Browser.Navigate().Refresh();
            //waiting 5 seconds 
            //System.Threading.Thread.Sleep(5000);
        }
        [Test]
        // Test-case �1.2
        public void test_1_Switching_Pages()
        {

            //Finding element with Feedback link
            IWebElement LinkContacts = Browser.FindElement(By.PartialLinkText("��������"));
            //Clicking on element with Feedback link
            LinkContacts.Click();
            //waiting 5 seconds 
            //System.Threading.Thread.Sleep(5000);
            //Finding element with Feedback link
            LinkContacts = Browser.FindElement(By.PartialLinkText("��������"));
            //Clicking on element with Order link
            LinkContacts.Click();
            //waiting 3 seconds 
            //System.Threading.Thread.Sleep(3000);
            //Finding element with Order link
            IWebElement LinkOrder = Browser.FindElement(By.PartialLinkText("� ���"));
            //Clicking on element with Order link
            LinkOrder.Click();
            //waiting 5 seconds 
            //System.Threading.Thread.Sleep(5000);
            //Finding element with Order link
            IWebElement LinkAbout = Browser.FindElement(By.PartialLinkText("� ���"));
            //Clicking on element with Order link
            LinkAbout.Click();
            //Finding element with About link
            IWebElement LinkRegistration = Browser.FindElement(By.PartialLinkText("�����������"));
            //Clicking on element with About link
            LinkRegistration.Click();
            //Finding element with Services link
            IWebElement LinkHome = Browser.FindElement(By.PartialLinkText("�������"));
            //Clicking on element with Services link
            LinkHome.Click();
        }

        [Test]
        // Test-case �1.6
        public void test_2_Write_Feedback()
        {
            //Finding element with Feedback link
            IWebElement LinkContacts = Browser.FindElement(By.PartialLinkText("��������"));
            //Clicking on element with Feedback link
            LinkContacts.Click();
            //Searching field to insert Name
            IWebElement Name = Browser.FindElement(By.Name("feed_name"));
            //filling Name field 
            Name.SendKeys("����������");
            //Searching field to insert email
            IWebElement email = Browser.FindElement(By.Name("feed_email"));
            //filling email field 
            email.SendKeys("poset@mail.ru");
            //Searching field to insert subject
            IWebElement subject = Browser.FindElement(By.Name("feed_subject"));
            //filling subject field 
            subject.SendKeys("������");
            //Searching field to insert Feedback
            IWebElement Feedback = Browser.FindElement(By.Name("feed_text"));
            //filling Feedback field 
            Feedback.SendKeys("����� ����������� ���������� ������������ �������?");
            //Searching Submit button
            IWebElement Submit = Browser.FindElement(By.Name("send_message"));
            //Clicking Submit button
            Submit.Click();
        }

        [Test]
        // Test-case �1.8
        public void test_3_Write_Review()
        {
            //Searching field to insert Query
            IWebElement InputInputSearch = Browser.FindElement(By.Id("input-search"));
            //filling field and sending Query
            InputInputSearch.SendKeys("���������" + OpenQA.Selenium.Keys.Enter);
            //Finding element with Generator products link
            IWebElement LinkProducts = Browser.FindElement(By.PartialLinkText("Denzel DB950 ��������� ����������"));
            //Clicking on element with Generator products link
            LinkProducts.Click();
            //Finding element with ListReview button link 
            IWebElement ListReview = Browser.FindElement(By.XPath("/html/body/div/div[6]/ul/li[3]/a"));
            //Clicking on element with ListReview button link
            ListReview.Click();
            //Finding element with ButtonNewReview button link 
            IWebElement ButtonNewReview = Browser.FindElement(By.PartialLinkText("�������� �����"));
            //Clicking on element with ButtonNewReview button link
            ButtonNewReview.Click();
            //Searching field to insert Name
            IWebElement Name = Browser.FindElement(By.Id("name_review"));
            //filling Name field 
            Name.SendKeys("����������");
            //Searching field to insert good_review
            IWebElement goodreview = Browser.FindElement(By.Id("good_review"));
            //filling good_review field 
            goodreview.SendKeys("���");
            //Searching field to insert bad_review
            IWebElement badreview = Browser.FindElement(By.Id("bad_review"));
            //filling bad_review field 
            badreview.SendKeys("���� ���");
            //Finding element with comment
            IWebElement commentreview = Browser.FindElement(By.Id("comment_review"));
            //Clicking on element with comment
            commentreview.SendKeys("�� � � �� ������� ���� �����");
            //Searching Send button
            IWebElement ButtonAddReview = Browser.FindElement(By.Id("button-send-review"));
            //Clicking Send button
            ButtonAddReview.Click();
        }

        [Test]
        // Test-case �1.10
        public void test_4_Order_Products()
        {
            //Searching field to insert Query
            IWebElement InputSearch = Browser.FindElement(By.Id("input-search"));
            //filling field and sending Query
            InputSearch.SendKeys("Denzel DB950 ��������� ����������" + OpenQA.Selenium.Keys.Enter);
            //Finding element with Product to add to cart
            IWebElement LinkProductToCart = Browser.FindElement(By.XPath("/html/body/div/div[6]/ul/li/a"));
            //Clicking on element with Product link - adding to cart
            LinkProductToCart.Click();
            //Finding element with Cart link
            IWebElement LinkToCart = Browser.FindElement(By.XPath("/html/body/div/div[4]/p/a"));
            //Clicking on element to go to the Cart
            LinkToCart.Click();
            //Finding element with adding Product link
            IWebElement ButtonAddProduct = Browser.FindElement(By.XPath("//*[@id=\"block-content\"]/div[3]/div[3]/ul/li[3]/p"));
            //Clicking on element with adding Product link
            ButtonAddProduct.Click();
            //Clicking on element with adding Product link
            ButtonAddProduct.Click();
            //waiting for 2 seconds 
            System.Threading.Thread.Sleep(2000);
            //Finding element with Confirm link
            IWebElement ButtonGoToConfirm = Browser.FindElement(By.PartialLinkText("�����"));
            //Clicking on element with Confirm link
            ButtonGoToConfirm.Click();
            //Finding element with Delivery RadioButton
            IWebElement RadioButtonDelivery = Browser.FindElement(By.Id("order_delivery2"));
            //Clicking on element with Delivery RadioButton
            RadioButtonDelivery.Click();
            //Searching field to insert FIO
            IWebElement FieldFIO = Browser.FindElement(By.Name("order_fio"));
            //filling FIO field 
            FieldFIO.SendKeys("����������");
            //Searching field to insert email
            IWebElement FieldEmail = Browser.FindElement(By.Name("order_email"));
            //filling email field 
            FieldEmail.SendKeys("poset@mail.ru");
            //Searching field to insert Phone
            IWebElement FieldPhone = Browser.FindElement(By.Name("order_phone"));
            //filling Phone field 
            FieldPhone.SendKeys("88005553535");
            //Searching field to insert Address
            IWebElement Address = Browser.FindElement(By.Name("order_address"));
            //filling Address field 
            Address.SendKeys(" �. ������,�� ����������� � 18, �� 58");
            //Searching field to insert Comment
            IWebElement OrderComment = Browser.FindElement(By.Name("order_note"));
            //filling Comment field 
            OrderComment.SendKeys("���������, ����������");
            //Finding element with Completion link
            IWebElement ButtonGoToCompletion = Browser.FindElement(By.Name("submitdata"));
            //Clicking on element with Completion link
            ButtonGoToCompletion.Click();
            //Finding element with Finish link
            IWebElement ButtonGoToFinish = Browser.FindElement(By.PartialLinkText("��������"));
            //Clicking on element with Finish link
            ButtonGoToFinish.Click();
        }

        [Test]
        // Test-case �1.19
        public void test_5_Go_Auth()
        {
            //Finding element with Auth link
            IWebElement ButtonGoToAuth = Browser.FindElement(By.PartialLinkText("����"));
            //Clicking on element with Auth link
            ButtonGoToAuth.Click();
            //waiting for 2 seconds 
            System.Threading.Thread.Sleep(2000);
            //Searching field to insert Login
            IWebElement InputLogin = Browser.FindElement(By.Id("auth_login"));
            //filling Login field
            InputLogin.SendKeys("poset");
            //Searching field to insert Password
            IWebElement InputPassword = Browser.FindElement(By.Id("auth_pass"));
            //filling Password field
            InputPassword.SendKeys("12345678");
            //Finding element with Rememberme Checkbox
            IWebElement RememberMeCheckBox = Browser.FindElement(By.Name("rememberme"));
            //Clicking on element with Rememberme Checkbox
            RememberMeCheckBox.Click();
            //waiting for 2 seconds 
            System.Threading.Thread.Sleep(2000);
            //Finding element with FinishAuth link
            IWebElement ButtonFinishAuth = Browser.FindElement(By.XPath("//*[@id=\"button-auth\"]/a"));
            //Clicking on element with FinishAuth link
            ButtonFinishAuth.Click();
            //Finding element with AuthUserInfo link
            IWebElement AuthUserInfo = Browser.FindElement(By.Id("auth-user-info"));
            //Clicking on element with AuthUserInfo link
            AuthUserInfo.Click();
            //waiting for 2 seconds 
            System.Threading.Thread.Sleep(2000);
            //Finding element with Logout link
            IWebElement Logout = Browser.FindElement(By.Id("logout"));
            //Clicking on element with Logout link
            Logout.Click();
        }

        [TearDown]
        public void test_LAST_Close()
        {
            //waiting 3 seconds 
            System.Threading.Thread.Sleep(3000);
            //quitting browser after test
            Browser.Quit();
        }
    }
}